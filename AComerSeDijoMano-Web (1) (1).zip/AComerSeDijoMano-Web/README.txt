A Comer Se Dijo “Mano” — Paquete web listo
----------------------------------------
Contenido del ZIP:
- index.html
- assets/
    - logo-final-a-comer-se-dojo.png
    - hero-burger.png
Instrucciones rápidas:
1) Abrir localmente:
   - Descomprime el ZIP.
   - Haz doble clic en index.html. Se abrirá en tu navegador.
2) Subir a Internet (Netlify, GitHub Pages):
   - Netlify: crea cuenta en netlify.com, arrastra la carpeta descomprimida al panel 'Sites' y listo.
   - GitHub Pages: crea un repo, sube los archivos (index.html y assets/), en Settings > Pages selecciona 'main' branch y carpeta '/'.
Contacto:
- Tel: 300-488-0827
- Email: acomersedijo@gmail.com
